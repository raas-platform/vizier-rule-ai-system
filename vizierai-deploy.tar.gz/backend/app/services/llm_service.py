"""
LLM 서비스 관리자
다양한 LLM 제공업체의 모델을 통합 관리
"""

from abc import ABC, abstractmethod
from typing import AsyncGenerator, Dict, List

import anthropic
import google.generativeai as genai
import openai

from ..config import SUPPORTED_MODELS, LLMModelConfig, settings
from ..utils.logger import get_logger


class BaseLLMProvider(ABC):
    """LLM 제공업체 기본 클래스"""

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.logger = get_logger(__name__)

    @abstractmethod
    async def generate_text(self, prompt: str, model_config: LLMModelConfig) -> str:
        """텍스트 생성"""
        pass

    @abstractmethod
    async def generate_stream(
        self, prompt: str, model_config: LLMModelConfig
    ) -> AsyncGenerator[str, None]:
        """스트리밍 텍스트 생성"""
        pass


class OpenAIProvider(BaseLLMProvider):
    """OpenAI 제공업체"""

    def __init__(self, api_key: str):
        super().__init__(api_key)
        self.client = openai.AsyncOpenAI(api_key=api_key)

    async def generate_text(self, prompt: str, model_config: LLMModelConfig) -> str:
        """OpenAI API를 사용한 텍스트 생성"""
        try:
            response = await self.client.chat.completions.create(
                model=model_config.model_name,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=model_config.max_tokens,
                temperature=model_config.temperature,
            )
            return response.choices[0].message.content
        except Exception as e:
            self.logger.error(f"OpenAI API 오류: {str(e)}", exc_info=True)
            raise

    async def generate_stream(
        self, prompt: str, model_config: LLMModelConfig
    ) -> AsyncGenerator[str, None]:
        """OpenAI API를 사용한 스트리밍 생성"""
        try:
            stream = await self.client.chat.completions.create(
                model=model_config.model_name,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=model_config.max_tokens,
                temperature=model_config.temperature,
                stream=True,
            )
            async for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            self.logger.error(f"OpenAI 스트리밍 오류: {str(e)}", exc_info=True)
            raise


class AnthropicProvider(BaseLLMProvider):
    """Anthropic 제공업체"""

    def __init__(self, api_key: str):
        super().__init__(api_key)
        self.client = anthropic.AsyncAnthropic(api_key=api_key)

    async def generate_text(self, prompt: str, model_config: LLMModelConfig) -> str:
        """Anthropic API를 사용한 텍스트 생성"""
        try:
            response = await self.client.messages.create(
                model=model_config.model_name,
                max_tokens=model_config.max_tokens,
                temperature=model_config.temperature,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        except Exception as e:
            self.logger.error(f"Anthropic API 오류: {str(e)}", exc_info=True)
            raise

    async def generate_stream(
        self, prompt: str, model_config: LLMModelConfig
    ) -> AsyncGenerator[str, None]:
        """Anthropic API를 사용한 스트리밍 생성"""
        try:
            async with self.client.messages.stream(
                model=model_config.model_name,
                max_tokens=model_config.max_tokens,
                temperature=model_config.temperature,
                messages=[{"role": "user", "content": prompt}],
            ) as stream:
                async for text in stream.text_stream:
                    yield text
        except Exception as e:
            self.logger.error(f"Anthropic 스트리밍 오류: {str(e)}", exc_info=True)
            raise


class GoogleProvider(BaseLLMProvider):
    """Google Gemini 제공업체"""

    def __init__(self, api_key: str):
        super().__init__(api_key)
        genai.configure(api_key=api_key)

    async def generate_text(self, prompt: str, model_config: LLMModelConfig) -> str:
        """Google Gemini API를 사용한 텍스트 생성"""
        try:
            model = genai.GenerativeModel(model_config.model_name)
            response = await model.generate_content_async(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    max_output_tokens=model_config.max_tokens,
                    temperature=model_config.temperature,
                ),
            )
            return response.text
        except Exception as e:
            self.logger.error(f"Google API 오류: {str(e)}", exc_info=True)
            raise

    async def generate_stream(
        self, prompt: str, model_config: LLMModelConfig
    ) -> AsyncGenerator[str, None]:
        """Google Gemini API를 사용한 스트리밍 생성"""
        try:
            model = genai.GenerativeModel(model_config.model_name)
            response = await model.generate_content_async(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    max_output_tokens=model_config.max_tokens,
                    temperature=model_config.temperature,
                ),
                stream=True,
            )
            async for chunk in response:
                if chunk.text:
                    yield chunk.text
        except Exception as e:
            self.logger.error(f"Google 스트리밍 오류: {str(e)}", exc_info=True)
            raise


class LLMService:
    """LLM 서비스 통합 관리자"""

    def __init__(self):
        self.logger = get_logger(__name__)
        self.providers: Dict[str, BaseLLMProvider] = {}
        self._initialize_providers()

    def _initialize_providers(self):
        """제공업체 초기화"""
        # OpenAI
        if settings.openai_api_key:
            self.providers["openai"] = OpenAIProvider(settings.openai_api_key)
            self.logger.info("OpenAI 제공업체 초기화 완료")

        # Anthropic
        if settings.anthropic_api_key:
            self.providers["anthropic"] = AnthropicProvider(settings.anthropic_api_key)
            self.logger.info("Anthropic 제공업체 초기화 완료")

        # Google
        if settings.google_api_key:
            self.providers["google"] = GoogleProvider(settings.google_api_key)
            self.logger.info("Google 제공업체 초기화 완료")

    def get_available_models(self) -> List[Dict[str, str]]:
        """사용 가능한 모델 목록 반환"""
        available_models = []
        for model_id, config in SUPPORTED_MODELS.items():
            if config.provider in self.providers:
                available_models.append(
                    {
                        "id": model_id,
                        "provider": config.provider,
                        "display_name": config.display_name,
                        "description": config.description,
                        "max_tokens": config.max_tokens,
                    }
                )
        return available_models

    def is_model_available(self, model_id: str) -> bool:
        """모델 사용 가능 여부 확인"""
        if model_id not in SUPPORTED_MODELS:
            return False
        config = SUPPORTED_MODELS[model_id]
        return config.provider in self.providers

    async def generate_text(self, prompt: str, model_id: str) -> str:
        """선택된 모델로 텍스트 생성"""
        if not self.is_model_available(model_id):
            raise ValueError(f"모델 '{model_id}'을(를) 사용할 수 없습니다.")

        config = SUPPORTED_MODELS[model_id]
        provider = self.providers[config.provider]

        self.logger.info(f"텍스트 생성 시작: {config.display_name}")
        result = await provider.generate_text(prompt, config)
        self.logger.info(f"텍스트 생성 완료: {len(result)}자")

        return result

    async def generate_stream(
        self, prompt: str, model_id: str
    ) -> AsyncGenerator[str, None]:
        """선택된 모델로 스트리밍 텍스트 생성"""
        if not self.is_model_available(model_id):
            raise ValueError(f"모델 '{model_id}'을(를) 사용할 수 없습니다.")

        config = SUPPORTED_MODELS[model_id]
        provider = self.providers[config.provider]

        self.logger.info(f"스트리밍 생성 시작: {config.display_name}")
        async for chunk in provider.generate_stream(prompt, config):
            yield chunk


# 전역 LLM 서비스 인스턴스
llm_service = LLMService()
